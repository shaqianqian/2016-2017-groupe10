!!Ecstatic Website

This is the source code of Ecstatic's website deployed in http://guillep.github.io/ecstatic. Just change the contents of this directory if you want to change the site.